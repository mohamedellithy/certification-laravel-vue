<header class="header">	    
    <div class="branding">
        <div class="container-fluid position-relative py-3">
            <div class="logo-wrapper">
                <div class="site-logo">
                    <a class="navbar-brand" href="{{ url('/') }}">
                        <img class="logo-icon me-2" src="{{ asset('asset/images/logo-w.png') }}" alt="logo" >
                    </a>
                </div>    
            </div><!--//docs-logo-wrapper-->
        </div><!--//container-->
    </div><!--//branding-->
</header>
<style>
    .logo-icon{ width: 150px; }
</style>