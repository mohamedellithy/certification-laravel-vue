<footer class="footer">
    <div class="footer-bottom text-center py-5">
        <!--/* This template is free as long as you keep the footer attribution link. If you'd like to use the template without the attribution link, you can buy the commercial license via our website: themes.3rdwavemedia.com Thank you for your support. :) */-->
        <small class="copyright">Developed with <i class="fas fa-heart" style="color: #fb866a;"></i> by <a class="theme-link" href="https://www.upwork.com/freelancers/~01b416d4df9d7d7bb3" target="_blank">Egyption </a> developers</small>
    </div>
</footer>