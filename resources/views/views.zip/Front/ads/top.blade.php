<div class="ads-top-side">
    {!! show_adsense($page_name ?? null,1)  !!}
</div>
<style>
    .ads-top-side{
        width: 80%;
        /* background-color: red; */
        height: auto;
        margin: 0% 10%;
        text-align: center;
    }
</style>