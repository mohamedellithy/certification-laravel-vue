<div class="ads-bottom-side">
    {!! show_adsense($page_name ?? null,2)  !!}
</div>
<style>
    .ads-bottom-side{
        width: 80%;
        /* background-color: red; */
        height: auto;
        margin: 0% 10%;
        text-align: center;
    }
</style>