<div class="ads-right-side">
    {!! show_adsense($page_name ?? null,3)  !!}
</div>
<style>
    .ads-right-side{
        position: fixed;
        width: 8%;
        /* background-color: red; */
        height: auto;
        right:0;
        text-align: center;
    }
</style>