<div class="ads-left-side">
    {!! show_adsense($page_name ?? null,4)  !!}
</div>
<style>
    .ads-left-side{
        position: fixed;
        width: 8%;
        /* background-color: red; */
        height: auto;
        left:0;
        text-align: center;
    }
</style>