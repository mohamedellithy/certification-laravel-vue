<div class="ads-after-title">
    {!! show_adsense($page_name ?? null,5)  !!}
</div>
<style>
    .ads-after-title{
        width: 80%;
        /* background-color: red; */
        height: auto;
        margin: 0% 10%;
        text-align: center;
    }
</style>
