
<!DOCTYPE html>
<html lang="en" dir="rtl"> 
<head>
    <!-- Theme CSS -->  
    <script src="{{ asset('js/app.js') }}" defer></script>
    <link id="theme-style" rel="stylesheet" href="{{ asset('front/css/theme.css') }}">
    <!-- import fonts  -->
    @forelse($fonts as $font)
        <style>
        @font-face{
            font-family:"{{ $font->font_family }}";
            src: url("{{ $font->full_url_file ?? $font->cdn_font_url }}") format("truetype");
        }
        </style>
    @empty
    @endforelse
</head>
<body>
    <section id="app" class="benefits-section theme-bg-light-gradient py-5">
        <screenshot-certification :fonts="{{ $fonts ?: [] }}" :data="{{ $info_data ?: [] }}" :certification="{{ $certification ?: [] }}" image="{{ $certification->image ? $certification->image->url : null }}"></screenshot-certification>
    </section>
</body>
</html> 