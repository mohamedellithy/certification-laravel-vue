<template>
    <div class="row">
        <div class="col-lg-6 d-flex flex-column">
            <div class="row flex-grow">
                <div class="col-12 grid-margin stretch-card">
                    <div class="card card-rounded">
                        <div class="card-body">

                            <div class="chartjs-bar-wrapper mt-3">
                                <div class="chartjs-size-monitor">
                                    <div class="chartjs-size-monitor-expand">
                                        <div class=""></div>
                                    </div>
                                    <div class="chartjs-size-monitor-shrink">
                                        <div class=""></div>
                                    </div>
                                </div>
                                <div  :key="count" style="display: block;height: 506px;max-height: 506px;min-height: 506px" class="certification-render-monitor some-selector">
                                    <div class="screenshot-border"></div>
                                    <img class="img-fluid" :src="image || null"/>
                                    <div v-for="(draggable,key) in draggables"
                                        :item="`${key}`"
                                        :id="`myDraggable${draggable.id || (draggable.key ? draggable.key : 0)}`"
                                        :class="['draggable' , views.indexOf(key) != -1 ? 'trans' : '' ]"
                                        :key="draggable.id || (draggable.key ? draggable.key : 0)"
                                        :data-x="draggable.transformX ? draggable.transformX : 0"
                                        :data-y="draggable.transformY ? draggable.transformY : 0"
                                        :f="draggable.view"
                                        :style="{  color     : `${draggable.color_text}`,
                                                   fontSize  : `${draggable.font_size_text}px`,
                                                   direction : `${draggable.direction_text}`,
                                                   textAlign : `${draggable.text_align}`,
                                                   transform : `translate(${draggable.transformX ? draggable.transformX : 0}px,${draggable.transformY ? draggable.transformY : 0}px)`,
                                                   width     : `${draggable.width_box  ? draggable.width_box : 0}px`,
                                                   height    : `${draggable.height_box ? draggable.height_box : 0}px`,
                                                   fontFamily: `${draggable.font ? draggable.font.font_family : '' }`
                                                 }">
                                            <link rel="stylesheet" v-if="draggable.font" :href="`${draggable.font.full_url_file || draggable.font.cdn_font_url}`" defer/>
                                            <template v-if="draggable.type_field == 1" >
                                                {{ data[draggable.id].value || null }}
                                            </template>

                                            <template v-if="draggable.type_field == 3">
                                                {{ (data[draggable.id].value || null) | FormatDateRules(draggable) }}
                                            </template>

                                            <template v-if="draggable.type_field == 2">
                                                <img v-if="data[draggable.id].value" :src="[data[draggable.id].value]"
                                                     :style="{
                                                        width     : `${draggable.image_width  ? draggable.image_width : 0}%`,
                                                        height    : `${draggable.image_height ? draggable.image_height : 0}%`
                                                }"/>
                                            </template>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
    </div>
</template>

<script>
import interact from "interactjs";
export default {
    data() {
        return {
            screenX: 0,
            screenY: 0,
            options:{
                edit:-1,
                target:null,
                type_field:1,
                font:null
            },
            deletes:[],
            draggables:[],
            index:0,
            errors:[],
            views:[],
            count:1
        };
    },
    props: ["certification","image",'Fonts','data'],
    mounted:function(){
        let self = this;
        this.draggables = this.certification.options;
        console.log(this.draggables);
        this.index      = this.certification.options.length;
        setTimeout(function(){
            self.certification.options.forEach(function(draggable,key){
                self.initInteract(document.getElementById(`myDraggable${draggable.id}`));
            });
        },2000);
        console.log(this.data);
    },
    methods: {
        initInteract: function(selector) {
            let self = this;
            interact(selector).draggable({
                // enable inertial throwing
                inertia: true,
                // keep the element within the area of it's parent
                restrict: {
                    restriction: "parent",
                    endOnly: true,
                    elementRect: { top: 0, left: 0, bottom: 1, right: 1 }
                },
                // enable autoScroll
                autoScroll: true,
                // call this function on every dragmove event
                onmove: this.dragMoveListener,
                // call this function on every dragend event
                onend: this.onDragEnd
            }).resizable({
                // resize from all edges and corners
                edges: { left: true, right: true, bottom: true, top: true },
                listeners: {
                    move (event) {
                        var target = event.target
                        var x = (parseFloat(target.getAttribute('data-x')) || 0)
                        var y = (parseFloat(target.getAttribute('data-y')) || 0)

                        // update the element's style
                        target.style.width = event.rect.width + 'px'
                        target.style.height = event.rect.height + 'px'

                        // translate when resizing from top or left edges
                        x += event.deltaRect.left
                        y += event.deltaRect.top

                        target.style.transform = 'translate(' + x + 'px,' + y + 'px)'

                        target.setAttribute('data-x', x)
                        target.setAttribute('data-y', y)

                        self.draggables[target.getAttribute('item')].transformX = x;
                        self.draggables[target.getAttribute('item')].transformY = y;
                        self.draggables[target.getAttribute('item')].height_box = event.rect.height;
                        self.draggables[target.getAttribute('item')].width_box  = event.rect.width;
                        //console.log(" height : "+event.rect.height);
                        console.log(self.draggables);
                        // target.textContent = Math.round(event.rect.width) + '\u00D7' + Math.round(event.rect.height)
                    }
                },
                modifiers: [
                    // keep the edges inside the parent
                    interact.modifiers.restrictEdges({
                        outer: 'parent'
                    }),

                    // minimum size
                    interact.modifiers.restrictSize({
                        min: { width: 100, height: 50 }
                    })
                ],
                inertia: true
            });
        }
    }
}
</script>
<style>
.list-item{
    padding: 10px;
    border: 12px solid #eee;
}
.card-title-dash{
    padding:10px 0px;
}
.draggable {
  width: 120px;
  padding: 12px 10px;
  margin: 1rem;
  background-color: transparent;
  color: white;
  font-size: 20px;
  font-family: sans-serif;
  touch-action: none;
  /* position: relative;
  display: inline-block; */
  /* This makes things *much* easier */
  box-sizing: border-box;
  /*border-radius: 30px;*/
}
.list-item a
{
    font-size: 15px;
    text-decoration: none;
    font-weight: bold;
    color: #1f3bb3;
}
.btn-toggle-nav.list-unstyled li a{
    font-size: 13px;
    color: #000000;
}
.list-wrapper ul li {
    font-size: 0.9375rem;
    padding: 0;
    border-bottom: unset;
}
.btn-toggle-nav li .form-control-lg
{
    min-height: 0.5rem !important;
    height: 0.5rem !important;
    padding: 0.94rem;
}
.options-settings{
    left: 1px;
    top: -25px;
    font-size: 21px;
    color: #880e4f;
    position: absolute;
    background-color: white;
    border-radius: 30px;
    padding: 2px 6px 1px 6px;
    cursor: pointer;
}
.options-delete{
    left: 40px;
    top: -25px;
    font-size: 21px;
    color: #880e4f;
    position: absolute;
    background-color: white;
    border-radius: 30px;
    padding: 2px 6px 1px 6px;
    cursor: pointer;
}
.Label-Field{
    right: 0px;
    top: -25px;
    font-size: 21px;
    color: #880e4f;
    position: absolute;
    border-radius: 30px;
    padding: 2px 6px 1px 6px;
    cursor: pointer;
}
.options-view{
    left: 80px;
    top: -25px;
    font-size: 21px;
    color: #880e4f;
    position: absolute;
    background-color: white;
    border-radius: 30px;
    padding: 2px 6px 1px 6px;
    cursor: pointer;
}
.trans{
    background-color: transparent !important;
}
.screenshot-border{
    position: absolute;
    left: 30px;
    right: 15px;
    background-color: transparent;
    top: 32px;
    bottom: 18px;
}
</style>
